ORU VASANTHATHIN VAASAM — EDITABLE FILM PROJECT

Working title: ஒரு வசந்தத்தின் வாசம்
This is a suggested title taken from the final line. The poet supplied no title
or author credit; no author has been invented.

The first cut is 100 seconds, 720 x 1280, with all 35 Tamil lines preserved in
order, original ambient music, and AI-generated seasonal-tree film stills.
It contains no spoken narration: the environment's online Tamil speech service
was blocked by network policy when the film was made.

Included:
  poem.txt                 Original Tamil poem, unchanged.
  captions.srt             Ten timed captions spanning 00:00 to 01:40.
  images/scene-01..10.png   Individual portrait background stills.
  project.json             Scene text, imagery directions, and render settings.
  render-request.json      Original request for the running studio instance.
  poster.jpg               First-scene poster.
  render_again.py          Upload these assets to a running studio and re-render.

The JSON's old image IDs are local to the original studio. The helper uploads
the included images afresh, so the project can be used in another instance.
You can replace the PNG backgrounds with your own photos, keeping the filenames.
To change the film title or timing, edit project.json under request.

To render again:
  1. Start Kavithai to Clip using ./run.sh from its repository.
  2. Activate its Python environment, which includes httpx.
  3. From this extracted project folder run:

       python render_again.py --output my-film.mp4

To add a narration recording you are authorized to use:

       python render_again.py --audio my-reading.wav --output narrated-film.mp4

The app validates the audio (maximum 25 MB and two minutes). Longer narration
extends the video. Scene timings can be adjusted in project.json for closer
line-by-line synchronization. This project contains no Vairamuthu voice model.

The ten-scene emotional arc:
  1  Frost and bare branches, dark sky                   00:00–00:10
  2  Rain awakens the roots                             00:10–00:20
  3  New leaves in sun and breeze                       00:20–00:30
  4  Gold reaches the green edges                       00:30–00:40
  5  Autumn admired; the tree bids farewell              00:40–00:50
  6  A photographer's colour; the tree's silence         00:50–01:00
  7  Photographs fill while the crown empties            01:00–01:10
  8  Each fallen leaf becomes a memory in the soil       01:10–01:20
  9  Bare branches hold only the sky again               01:20–01:30
 10  Spring remains asleep within the roots              01:30–01:40
