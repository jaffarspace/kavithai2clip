"""Re-render the included scene project, optionally with an authorized recording."""

import argparse
import copy
import json
import time
from pathlib import Path

import httpx


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--audio", type=Path, help="Optional narration recording, maximum two minutes")
    parser.add_argument("--output", type=Path, default=Path("rendered.mp4"))
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit("The output already exists. Choose another --output filename.")
    root = Path(__file__).resolve().parent
    project = json.loads((root / "project.json").read_text(encoding="utf-8"))
    request = copy.deepcopy(project["request"])
    with httpx.Client(base_url=args.base_url, trust_env=False, timeout=30) as client:
        for scene, visual in zip(request["scenes"], project["visual_plan"], strict=True):
            path = root / visual["image"]
            with path.open("rb") as stream:
                response = client.post("/api/assets", files={"file": (path.name, stream, "image/png")})
            response.raise_for_status()
            scene["image_id"] = response.json()["id"]
        if args.audio:
            with args.audio.open("rb") as stream:
                response = client.post("/api/assets", files={
                    "file": (args.audio.name, stream, "audio/mpeg"),
                })
            response.raise_for_status()
            request["narration"] = "upload"
            request["narration_asset_id"] = response.json()["id"]
        response = client.post("/api/render", json=request)
        response.raise_for_status()
        job_id = response.json()["job_id"]
        deadline = time.monotonic() + 300
        while time.monotonic() < deadline:
            response = client.get(f"/api/jobs/{job_id}")
            response.raise_for_status()
            job = response.json()
            if job["status"] == "failed":
                raise RuntimeError(job["error"])
            if job["status"] == "complete":
                response = client.get(job["video_url"])
                response.raise_for_status()
                args.output.write_bytes(response.content)
                print(f"Saved {args.output}: {job['duration']} seconds")
                return
            time.sleep(1)
    raise TimeoutError("The render did not complete within five minutes")


if __name__ == "__main__":
    main()
