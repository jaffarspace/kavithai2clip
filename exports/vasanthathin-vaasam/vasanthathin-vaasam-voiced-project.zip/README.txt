NARRATED POETRY CUT — ஒரு வசந்தத்தின் வாசம்

This cut contains all35 original lines, stock Tamil Valluvar narration with
phrase-directed rate/pitch/volume, intentional silences, music, and smooth
dissolves. It lasts105.768 seconds. The backgrounds remain AI-generated
stills with camera movement. TrueAI moving footage has not been generated.

The included captions.srt follows the measured narration timing.
The narration-plan.json preserves the performance timing and direction.
motion-plan.json describes possible future genuine image-to-video scenes;
it is a prompt plan, not generated footage.

To render this project against a running Kavithai studio:
  python render_again.py --output remake.mp4

To reuse the exact included recording rather than synthesize again:
  python render_again.py --audio tamil-poetry-narration.mp3 --output remake.mp4

Activate the studio's Python environment first. You can replace scene PNGs
with your own pictures. The app also accepts moving MP4/MOV/WebM clips.
The standard Tamil voice does not require a Runway account.
